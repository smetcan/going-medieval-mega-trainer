﻿========================================================================
   GOING MEDIEVAL - MEGA TRAINER (EN / TR) v1.5.0 - INSTALLATION GUIDE
========================================================================

1. INSTALLATION (ONE STEP - NO EXTRA TOOLS NEEDED)
------------------------------------------------------------------------
Extract ALL files and folders inside this ZIP archive:
  - BepInEx (folder)
  - winhttp.dll
  - doorstop_config.ini

directly into your "Going Medieval.exe" root game folder:

  * Epic Games default path:
    C:\Program Files\Epic Games\GoingMedieval\

  * Steam default path:
    C:\Program Files (x86)\Steam\steamapps\common\Going Medieval\

2. USAGE, LANGUAGE SWITCH & HOTKEYS
------------------------------------------------------------------------
Launch the game normally. You will see the "Mega Trainer v1.5.0 [F1]" badge
in the top-left corner.
* Default language is English (EN). Click "ğŸŒ Lang: EN â” TR" in the top bar
  to switch between English and Turkish at any time!

  [F1] or [Insert] : Open / Close Trainer Menu
  [F2]             : Open / Close Native Hidden Developer Panel
  [F3]             : Settler God Mode & Auto-Heal ON / OFF
  [F4]             : Infinite Needs & 100% Mood ON / OFF
  [F5]             : Instant Build + Free Build + Instant Dig/Cut ON / OFF
  [F6]             : Finish All Construction Blueprints on Map
  [F7]             : Refill All Stockpiles to Max & 100% Freshness
  [F8]             : Kill All Enemies on Map
  [F9]             : Live Hot-Reload (loads new updates without restarting)

========================================================================
   TÃœRKÃ‡E KURULUM VE KULLANIM KILAVUZU
========================================================================
1. Bu ZIP iÃ§indeki tÃ¼m dosyalarÄ± (BepInEx, winhttp.dll, doorstop_config.ini)
   "Going Medieval.exe" dosyasÄ±nÄ±n bulunduÄŸu oyun ana klasÃ¶rÃ¼ne kopyalayÄ±n.
2. Oyunu baÅŸlatÄ±p [F1] tuÅŸuna basÄ±n. MenÃ¼ varsayÄ±lan olarak Ä°ngilizce aÃ§Ä±lÄ±r;
   saÄŸ Ã¼stteki "ğŸŒ Lang: EN â” TR" butonuna tÄ±klayarak TÃ¼rkÃ§e'ye geÃ§ebilirsiniz.
========================================================================
